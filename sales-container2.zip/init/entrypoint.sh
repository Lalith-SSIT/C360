#!/bin/bash
set -e

until pg_isready -U postgres; do
  echo "Waiting for PostgreSQL..."
  sleep 2
done

# Enable pgvector extension
psql -U postgres -d C360 -c "CREATE EXTENSION IF NOT EXISTS vector;"

# Import embeddings if exists
if [ -f "/data/embeddings_export.sql" ]; then
  echo "Importing embeddings..."
  psql -U postgres -d C360 < /data/embeddings_export.sql
fi

# Import CSV files
for file in /data/temp/*.csv; do
  [ -e "$file" ] || continue
  table=$(basename "$file" .csv | tr '[:upper:]' '[:lower:]')
  echo "Importing $file into table $table..."

  header=$(head -n 1 "$file")
  columns=$(echo "$header" | awk -F',' '{for(i=1;i<=NF;i++) printf "%s TEXT%s", $i, (i<NF?", ":"")}')

  psql -U postgres -d C360 -c "DROP TABLE IF EXISTS $table;"
  psql -U postgres -d C360 -c "CREATE TABLE $table ($columns);"
  psql -U postgres -d C360 -c "\\COPY $table FROM '$file' DELIMITER ',' CSV HEADER;"
done
